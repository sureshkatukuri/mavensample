package net.systemshub;

public class User {
public String name,password,email;

public User(){}
public void setname (String name){
        this.name= name;
        }
public void setpassword(String password){
        this.password=password;

}
public void setemail(String email){
        this.email=email;

}

public String getname(){
        return name;

}
public String getpassword(){
        return password;
}
public String getemail(){
        return email;

}


}
